<?php $__env->startSection('content'); ?>

            <section class="user-cabinet beauty-wrapper">
            <div class="row">
                <div class="small-12 medium-12 columns">
                    <h1 class="title hide-for-small-only hide-for-medium-only hide-for-large-only"> Мой профиль </h1>
                </div>

                  <div class="small-12 medium-3 columns">
                                <?php echo $__env->make("profile.lib.left", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>

                <div class="small-12 medium-9 columns details">
                     <div class="form-group">
                        <a href="<?php echo e(route('products.create')); ?>" class="btn btn-success">Добавить</a>
                    </div>
                    <br>

                    <div class="latest-orders cabinet-block">
                        <div class="score_main">
                            <table class="score table">
                                <thead>
                                    <tr>
                                        <th>№</th>
                                        <th>Название</th>
                                        <th>Описание</th>
                                        <th>Сумма</th>
                                        <th>Статус</th>
                                        <th>Тип</th>
                                        <th>Действия</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if($prod->count()>0): ?>
                                    <?php $__currentLoopData = $prod; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($item->id); ?></td>
                                        <td><a target="_blank" href="<?php echo e(route('detail',['slug'=>$item->slug])); ?>"><span style="color: blue;"><?php echo e($item->title); ?></span></a></td>
                                        <td><?php echo $item->text; ?></td>
                                        <td><?php echo e($item->price); ?></td>
                                        <td><?php echo e($item->label); ?></td>
                                        <td>БУДЕТ ИЗ ЗАКАЗОВ</td>
                                        <td>


                            <a href="<?php echo e(route('products.edit',['id'=>$item->id])); ?>" class="fa fa-pencil-alt" style="float: left;"></a>

                                <form action="<?php echo e(route('products.destroy',['id'=>$item->id])); ?>" method="post">
                                    <?php echo csrf_field(); ?>

                                    <input type="hidden" name="_method" value="delete">
                                    <button onclick="return confirm('are you sure?')" type="submit" class="delete" style="float: left;border: 0;background: none; color: #0d6aad">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </form>


                            </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    <tr>
                                        <td colspan="6">
                                            <div class="free_score">
                                                <p></p>
                                                <h3 align="center">Нет данных</h3>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                            
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("main.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/lebazar/resources/views/profile/post/index.blade.php ENDPATH**/ ?>