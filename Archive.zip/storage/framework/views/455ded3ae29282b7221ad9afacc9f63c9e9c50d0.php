
                <section class="home-slider">
                    <div class="slick-slider">
                         <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <div> <img src="<?php echo e($item->getImage()); ?>" alt="" />
                             </div>
        

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        

                        
                    </div>
                </section>








<?php /**PATH /Applications/MAMP/htdocs/lebazar/resources/views/lib/slider.blade.php ENDPATH**/ ?>