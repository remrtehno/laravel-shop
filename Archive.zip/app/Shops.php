<?php

namespace App;
use Cviebrock\EloquentSluggable\Sluggable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;
use Intervention\Image\Facades\Image;

class Shops extends Model
{
    //
    use Sluggable;
    protected $table = "shops";
    protected $fillable =['title','anonce','user_id','img', 'address', 'map'];


    public function removeImage()
    {
        if($this->img != null)Storage::delete('/uploads/shopa/' . $this->img);
    }

    public  function products(){

        return $this->belongsTo("App\Product",'id','shop_id');
    }

    public function getProducts($id) {
        $cat = Product::where('shop_id', $id)->get();
        return $cat;
    }



    public static function add($fields)
    {
        $post = new static;
        $post->fill($fields);
        $post->save();
        return $post;
    }

    public function edit($fields)
    {
        $this->fill($fields);
        $this->save();
    }

    public function uploadImage($image)
    {
        if($image == null) { return; }

        $this->removeImage();
        $filename = str_random(10) . '.' . $image->extension();
        $pat = public_path().'/uploads/shops/'.$filename;
        $img = Image::make($image);
        $img->backup();
        $img->fit(248,217)->save($pat,100);
        $img->reset();
        $this->img = $filename;
        $this->save();
    }

    public function getImage()
    {
        if($this->img == null)
        {
            return '/uploads/no-image.jpg';
        }

        return '/uploads/shops/' . $this->img;

    }


		public function sluggable(): array
		{
		    return [
		        'slug' => [
		            'source' => 'title'
		        ]
		    ];
		}
}
