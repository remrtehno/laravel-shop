<?php $__env->startSection("content"); ?>


    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                Все заказы
                <small>it all starts here</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#">Examples</a></li>
                <li class="active">Все заказы</li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">

            <!-- Default box -->
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Все заказы</h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body">

                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                        <tr>
                            <th>Дата</th>
                            <th>Магазин</th>
                            <th>Название</th>
                            <th>Цена</th>
                            <th>Цена -0.3%</th>
                            <th>Кол-во</th>


                            
                        </tr>
                        </thead>
                        <tbody>

                        <?php if(!isset($orders)): ?> <?php $orders = []; ?> <?php endif; ?>

                        <?php if(isset($orders)): ?>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr >
                                <td><?php echo e($item->created_at); ?></td>
                                <td>
                                    <?php echo e($item->getShop() ? $item->getShop()->title : ''); ?>

                                    <a style="float: right;" onclick=" $(this.nextElementSibling).toggle()">Детали</a>
                                    <div style="display: none;">
                                        <?php if($item->getShop()): ?>
                                            Адрес: <?php echo e($item->getShop()->address); ?> <br>
                                            <?php echo e($item->getShop()->text); ?>

                                            <img src="<?php echo e($item->getShop()->getImage()); ?>" height="80" >
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td><?php echo e($item->tovar_name); ?></td>
                                
                                <td> <?php echo e($item->tovar_price); ?> <br>
                                    <b>Общая:</b> <?php echo e((int)$item->tovar_price * (int)$item->qty); ?>

                                </td>
                                <td> <?php echo e((int)$item->tovar_price * 0.7); ?> <br>
                                    <b>Общая:</b> <?php echo e((int)$item->tovar_price * 0.7 * (int)$item->qty); ?>

                                </td>
                                <td> <?php echo e($item->qty); ?></td>







                                
                                    
                                        
                                        

                                        
                                                


                                        
                                    


                                    
                                        

                                        
                                        
                                                
                                            
                                        
                                    
                                
                            </tr>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                        </tfoot>
                    </table>
                </div>
                <!-- /.box-body -->



                <!--

                <div class="box-body">

                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                        <tr>
                            <th>Дата</th>
                            <th>Магазин</th>
                            <th>Название</th>
                            <th>Статус</th>
                            <th>Цена</th>
                            <th>Цена с доставкой</th>

                            <th>Наличными</th>
                            <th>Действия</th>
                        </tr>
                        </thead>
                        <tbody>

                        <?php if(!isset($orders)): ?> <?php $orders = []; ?> <?php endif; ?>

                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr <?php echo e($item->status == 'Ожидает' ? 'bgcolor=pink' : ''); ?> <?php echo e($item->status == 1 ? 'bgcolor=lightgreen' : ''); ?> >
                                <td><?php echo e($item->created_at); ?></td>
                                <td><?php echo e($item->getShop() ? $item->getShop()->title : ''); ?></td>
                                <td><?php echo e($item->tovar_name); ?></td>
                                <td><?php echo e($item->getStatus()); ?></td>
                                <td> <?php echo e($item->tovar_price); ?></td>
                                <td><?php echo e($item->getMeta('total')); ?></td>


                                <td><?php echo e($item->typeBill()); ?></td>


                                <td>
                                    <form action="<?php echo e(route('orders.update',['id'=>$item->id])); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="_method" value="PUT">

                                        <button style="float: left;border: 0;background: none; color: #0d6aad"
                                                type="submit" class="fa fa-check delete" style="float: left;">


                                        </button>
                                    </form>


                                    <form action="<?php echo e(route('orders.destroy',['id'=>$item->id])); ?>" method="post">
                                        <?php echo csrf_field(); ?>

                                        <input type="hidden" name="_method" value="delete">
                                        <button onclick="return confirm('are you sure?')" type="submit" class="delete"
                                                style="float: left;border: 0;background: none; color: #0d6aad">
                                            <i class="fa fa-remove"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tfoot>
                    </table>
                </div>
                <!-- /.box-body -->

            </div>
            <!-- /.box -->

            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Детали заказа</h3>
                </div>
                <!-- /.box-header -->

                <div class="box-body" style="font-size:18px; font-weight:400;">
                    <?php if(isset($item)): ?>
                    <b>Общая цена</b>:  <?php echo e($item->getMeta('total')); ?> сум<br>
                    <b>Имя клиента</b>:  <?php echo e($item->getMeta('name_customer')); ?> <br>
                    <b>E-mail клиента</b>:  <?php echo e($item->getMeta('email_customer')); ?> <br>
                    <b>Телефон клиента</b>:  <?php echo e($item->getMeta('phone_customer')); ?> <br>
                    <b>Адрес клиента</b>:  <?php echo e($item->getMeta('address_customer')); ?> <br>
                    <b>Пожелания клиента</b>:  <?php echo e($item->getMeta('text_customer')); ?> <br>
                    <b>Доставка</b>:  <?php echo e($item->getMeta('delivery') == 'on' ? 'Доставка' : 'Самовызов'); ?> <br>
                    <?php else: ?>
                        Пусто
                    <?php endif; ?>

                </div><!-- /.box-body -->


            </div>
            <!-- /.box -->

        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.main.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/lebazar/resources/views/admin/orders/detail.blade.php ENDPATH**/ ?>