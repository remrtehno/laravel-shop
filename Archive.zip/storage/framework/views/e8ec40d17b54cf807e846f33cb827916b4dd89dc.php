<?php $__env->startSection('content'); ?>

            <section class="user-cabinet beauty-wrapper">
            <div class="row">
                <div class="small-12 medium-12 columns">
                    <h1 class="title hide-for-small-only hide-for-medium-only hide-for-large-only"> 
                        <?php echo app('translator')->getFromJson('home.profile_my'); ?>
                    </h1>
                </div>

                  <div class="small-12 medium-3 columns">
                                <?php echo $__env->make("profile.lib.left", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>

                <div class="small-12 medium-9 columns details">
                     <div class="form-group">
                        <a href="<?php echo e(route('seller-shops.create')); ?>" class="btn btn-success">
                             <?php echo app('translator')->getFromJson('home.add'); ?>
                        </a>
                    </div>
                    <br>

                   <div class="latest-orders cabinet-block">
                        <?php if($shops->count()>0): ?>
                        <table class="score table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th width="200">
                                        <?php echo app('translator')->getFromJson('home.profile_shops'); ?>
                                    </th>
                                    <th>
                                        <?php echo app('translator')->getFromJson('home.orders_desc'); ?>
                                    </th>
                                    <th><?php echo app('translator')->getFromJson('home.orders_actions'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->id); ?></td>
                                    <td><?php echo e($item->getTitle()); ?></td>
                                    <td><?php echo $item->anonce; ?></td>
                                    <td> 

                                       <a href="<?php echo e(route('seller-shops.edit',['id'=>$item->id])); ?>" class="fa fa-pencil-alt" style="float: left;"></a>

                                <form action="<?php echo e(route('seller-shops.destroy',['id'=>$item->id])); ?>" method="post">
                                    <?php echo csrf_field(); ?>

                                    <input type="hidden" name="_method" value="delete">
                                    <button onclick="return confirm('are you sure?')" type="submit" class="delete" style="float: left;border: 0;background: none; color: #0d6aad">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </form>

                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php else: ?>

                        <div align="center"><img src="/assets/img/free_score.png" alt="No datas"><br> <br>
                            <h3>Пусто</h3>
                        </div>

                        <?php endif; ?>
                    </div>



                </div>
                </div>
            </div>
        </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("main.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/lebazar/resources/views/profile/shops/index.blade.php ENDPATH**/ ?>