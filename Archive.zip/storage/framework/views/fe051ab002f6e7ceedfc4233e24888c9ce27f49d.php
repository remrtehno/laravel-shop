



<?php $__env->startSection('content'); ?>

<main>
    <div class="container-fluid wrapper-shop">
        
    
        <div class="row">
            <div class="col-md-4 col-lg-3">
                <div class="shop-wrap">
                    <img src="<?php echo e($shop->getImage()); ?>" alt="">
                    <div class="about-shop">
                        <h5><?php echo e($shop->title); ?></h5>
                    
                    <p></p>
                    <h5 class="title"><?php echo app('translator')->getFromJson('home.about_shop'); ?></h5>
                    <p></p>
                    <div class="shop-description">
                        <?php echo $shop->anonce; ?>

                    </div><!-- /.shop-description -->
                    <p></p>
                    <h5 class="title-address"><?php echo app('translator')->getFromJson('home.address_shop'); ?>:</h5>
                    <div class="address">
                        <?php echo $shop->address; ?>

                    </div><!-- /.address -->
                    </div><!-- /.about-shop -->
                    <?php if($shop->map): ?>
                    <div class="map">
                        <div id="shop-<?php echo e($shop->id); ?>" style="height: 200px;" class="map" data-map="<?php echo e($shop->map); ?>" data-title="<?php echo e($shop->title); ?>"></div><!-- /#shop-<?php echo e($shop->id); ?> -->
                    </div><!-- /.map -->    
                    <?php endif; ?>
                </div><!-- /.shop-wrap -->
            </div><!-- /.col-md-4 col-lg-3 -->
            <div class="col-md-8 col-lg-9">
                 <section class="products-container products-container-wrap">
                                                <div class="row small-up-2 medium-up-4 large-up-4" style="padding-left: 15px; padding-right: 15px">
                                                     <?php $__currentLoopData = $shop_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       
                                       
                                                    <div class="column no-column-padding">
                                                        <div class="product-item"> 
                                                            <a class="clickable" aria-current="false" href="<?php echo e(route('detail',['slug'=>$val->slug])); ?>">
                                                                <?php if($val->label): ?>
                                                                <div class="label-container"> <span class="label sale alert inline"><?php echo e($val->label); ?> %</span> </div>
                                                                <?php endif; ?>
                                                                <div class="bottom">
                                                                    <div class="product-image">
                                                                        <img src="<?php echo e($val->getImage()); ?>" class="product-img square-180" />
                                                                    </div>
                                                                    <h4 class="product-title"><?php echo e($val->title); ?></h4>
                                                                    <div class="product__price clearfix"> 
                                                                        <strong> <?php echo e($val->price); ?> <span>
<?php echo app('translator')->getFromJson('home.sumPerOne'); ?>
</span>
                                                                         </strong> 
                                                                </div>
                                                                <div class="add-cart horizontal cart-44732 wide-box not-added"> <button class="button expanded add-to-cart"> <span class="gl-shopping-cart"></span> 
                                                                    <?php echo app('translator')->getFromJson('home.tobasket'); ?>
                                                                 </button> </div>
                                                            </a> </div>
                                                    </div>
                                                </div>


                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    
                                                </div>
                                            </section>


            </div><!-- /.col-md-8 col-lg-9 -->
        </div><!-- /.row -->

</div><!-- /.container-fluid -->


        <section class="product-details-page">
            <div>

                <div class="similar-products beauty-wrapper animated fadeInUp normal">
                    <div class="row">
                        <div class="small-12">
                            <section class="products-container products-slider similar-products show">
                                <div class="row">
                                    <div class="small-12">
                                        <h4 class="section-title beauty-title">
                                            <?php echo app('translator')->getFromJson('home.catalog_best'); ?>
                                        </h4>
                                        <div>
                                            <section class="products-container products-container-wrap">
                                                <div class="row small-up-2 medium-up-4 large-up-6" style="padding-left: 15px; padding-right: 15px">
                                                     <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       
                                       
                                                    <div class="column no-column-padding">
                                                        <div class="product-item"> 
                                                            <a class="clickable" aria-current="false" href="<?php echo e(route('detail',['slug'=>$val->slug])); ?>">
                                                                <?php if($val->label): ?>
                                                                <div class="label-container"> <span class="label sale alert inline"><?php echo e($val->label); ?> %</span> </div>
                                                                <?php endif; ?>
                                                                <div class="bottom">
                                                                    <div class="product-image">
                                                                        <img src="<?php echo e($val->getImage()); ?>" class="product-img square-180" />
                                                                    </div>
                                                                    <h4 class="product-title"><?php echo e($val->title); ?></h4>
                                                                    <div class="product__price clearfix"> 
                                                                        <strong> <?php echo e($val->price); ?> 
                                                                           <span><?php echo app('translator')->getFromJson('home.sumPerOne'); ?></span> 
                                                                         </strong> 
                                                                </div>
                                                                <div class="add-cart horizontal cart-44732 wide-box not-added"> <button class="button expanded add-to-cart"> <span class="gl-shopping-cart"></span> <?php echo app('translator')->getFromJson('home.tobasket'); ?> </button> </div>
                                                            </a> </div>
                                                    </div>
                                                </div>


                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    
                                                </div>
                                            </section>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>



    

<?php $__env->stopSection(); ?>


<?php echo $__env->make("main.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/lebazar/resources/views/shops/detail.blade.php ENDPATH**/ ?>