



<?php $__env->startSection('content'); ?>

<style>
    .desc:empty {
        display: none;
    }
</style>
    <main>
        <section class="search-results product-list-container">
            <div class="row">
                <div class="small-12 medium-12">
                    <nav aria-label="You are here:" role="navigation" style="position: relative">
                        <ul class="breadcrumbs">
                            <li> <a href="/"><?php echo app('translator')->getFromJson('home.main'); ?> </a> </li>



                            
                        </ul>
                    </nav>
                </div>
                <div class="small-12 medium-2 side-column filter-side-wrap">
                    <div class="facet-filter-wrap">
                        <div class="facet-box categories-facet-box">
                            <div class="facet-box__header">
                                <h4 class="facet-box__title"> <span class="text"><?php echo app('translator')->getFromJson('home.cats'); ?></span> <span class="toggle-btn">                      <i class="fa fa-angle-down"></i>                    </span> </h4>
                            </div>
                            <div class="facet-box__body">
                                <div class="product-filter-menu">
                                    <ul class="menu vertical" data-animation="animated fadeInUp normal">

                                        <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        
                                        <li class=""> <a class="clickable" aria-current="true" href="<?php echo e(route('category',['slug'=>$item->slug])); ?>"> <?php echo e($item->title); ?> </a> </li>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </ul>
                                </div>
                            </div>
                        </div>


 <div class="facet-box price-range-facet">
                            <div class="facet-box__header">
                                <h4 class="facet-box__title"> <span class="text"><?php echo app('translator')->getFromJson('home.branchPrice'); ?></span> <span class="toggle-btn">                      <i class="fa fa-angle-down"></i>                    </span> </h4>
                            </div>
                            <div class="facet-box__body">
                                <div>
                                    <form class="price-range-form"> <input class="input-field price-field price-field-min" placeholder="Min" type="text" value="1000" /> <span>-</span> <input class="input-field price-field price-field-max" placeholder="Max" type="text" value="" /> <input type="submit" class="hide" value="Ok" /> </form>
                                    <div class="slider-range-box">
                                        <div id="slider-range"></div>
                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>
                </div>
                <div class="small-12 medium-10 products-column columns">
                    <div>
                        <section class="products-container animated fadeInUp normal" data-animation="animated fadeInUp normal">
                             <?php if($products->count()>0): ?>
                            <div class="row small-up-2 medium-up-4 large-up-5">
                                 <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="column no-column-padding" data-price="<?php echo e($item->price ?  $item->price : 0); ?>">
    <div class="product-item">
        <?php if($item->label): ?>
        <div class="label-container"> <span class="label sale alert inline"><?php echo e($item->label); ?> %</span> </div>
        <?php endif; ?>

        <div class="bottom">
            <a href="<?php echo e(route('detail',['slug'=>$item->slug])); ?>">
                <div class="product-image"> 
                    <div class="overlay">
                        <i class="fa fa-eye" aria-hidden="true"></i> <?php echo app('translator')->getFromJson('home.detail'); ?>
                    </div> 
                    <img src="<?php echo e($item->getImage()); ?>" class="product-img square-180" /> 
                </div>
                <h4 class="product-title"><?php echo e($item->title); ?></h4>
            </a>
            <div class="desc" style="height: 30px; overflow: hidden;">
                <?php echo str_limit($item->anonce,350); ?>

            </div>
            <div class="product__price clearfix"> 
                <strong>
                    <?php echo e($item->price ?  $item->price : 0); ?><span> сум.</span> 
                </strong>
            </div>
        </div> <!-- bottom -->
        <div class="add-cart horizontal cart-7286 wide-box not-added">
            <button class="button expanded add-to-cart"> <span class="gl-shopping-cart"><a style="color:white;" aria-current="false" href="<?php echo e(route('add',['slug'=>$item->id])); ?>"></span> <?php echo app('translator')->getFromJson('home.tobasket'); ?></a> </button>
        </div> <!-- add-cart -->
    </div><!--  product-item -->
</div> <!-- column -->
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                             <?php else: ?>
                                    <section class="lefd">
                                        <h2><?php echo app('translator')->getFromJson('home.nothing'); ?></h2>
                                    </section>
                                <?php endif; ?>
                        </section>

                        <?php echo e($products->links()); ?>

                    </div>
                </div>
            </div>
        </section>
    </main>




   
    

            
                                               



<?php $__env->stopSection(); ?>


<?php echo $__env->make("main.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/lebazar/resources/views/products/sale-hits.blade.php ENDPATH**/ ?>