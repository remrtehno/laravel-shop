
                    <div class="cabinet-menu">
                        <div class="">
                            <ul class="menu vertical no-bullet">
                                <li><a class="current icon profile" href="<?php echo e(route('profile-index')); ?>"><span ><?php echo app('translator')->getFromJson('home.profile_my'); ?></span></a></li>
                                
                                <?php if(Auth::user()->role == 'seller'){ ?>
                                <li> <a class="icon orders" aria-current="false" href="<?php echo e(route('products.index')); ?>">  <?php echo app('translator')->getFromJson('home.profile_products'); ?> </a> </li>
                                
                                <?php }else{?>
                                
                                <?php }?>

                                <li> <a class="icon bills" href="<?php echo e(route('orders')); ?>"><?php echo app('translator')->getFromJson('home.profile_orders'); ?></a> </li>

                      
<?php if(Auth::user()->role == 'seller'){?>
                                <li> <a class="icon shops" aria-current="false" href="<?php echo e(route('seller-shops.index')); ?>"> <?php echo app('translator')->getFromJson('home.profile_shops'); ?> </a> </li>
                                
                                   <?php }else{?>
                                
                                <?php }?>


                                
                                <li> <a class="icon watchlist" aria-current="false" href="<?php echo e(route('profile-watchlist')); ?>"> <?php echo app('translator')->getFromJson('home.profile_looked'); ?> </a> </li>
                                

                                 <?php if(Auth::user()->role == 'seller'){?>
                                <li class="magazine_act"> <a class="icon open-shops" aria-current="false" href="<?php echo e(route('seller-shops.create')); ?>">  <?php echo app('translator')->getFromJson('home.profile_open_shop'); ?> </a> </li>
                                
                                <?php }else{?>
                                
                                <?php }?>


                            </ul>
                        </div>
                    </div>


<?php /**PATH /Applications/MAMP/htdocs/lebazar/resources/views/profile/lib/left.blade.php ENDPATH**/ ?>