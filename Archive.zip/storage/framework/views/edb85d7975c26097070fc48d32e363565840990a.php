<?php $__env->startSection("content"); ?>

    <style>
        .badge {
            background: red;
        }
    </style>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                Магазины
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#">Examples</a></li>
                <li class="active">Blank page</li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">

            <div class="box">


                
                
                    
                        
                                                                                          
                                                                                          
                                                                                          

                            

                    
                

                
                

                    


                        
                            
                            
                            

                            


                        


                        
                            
                            
                            

                            
                                   
                            
                                   
                            
                        

                    


                    


                        
                            
                                


                                


                                


                                    
                                        
                                        
                                            
                                            
                                            
                                        
                                        

                                        
                                        
                                            
                                                
                                                    
                                                            
                                                        
                                                            
                                                        
                                                    
                                                
                                                
                                                    
                                                
                                                
                                                    
                                                
                                            
                                        

                                        
                                            
                                                
                                                    
                                                
                                                
                                                    
                                                
                                                
                                                    
                                                
                                            
                                        
                                        
                                    
                                




                            
                                
                            

                        

                    


                




                <div class="box-body " >


                    <table class="table DataTable">
                        <thead>
                        <tr>
                            <th>Магазин</th>
                            <th>Кол-во заказов сегодня</th>
                            <th>Общее кол-во заказов</th>
                        </tr>
                        </thead>

                        <tbody>
                        <?php $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><a href="<?php echo e(route('statisics.show', ['id' => $val->id,])); ?>"><b><?php echo e($val->title); ?></b></a></td>
                                <?php $__currentLoopData = $val->statisticsByDate($from, $to); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <td>
                                        <b>Кол-во:</b> <?php echo e($item->cnt); ?>

                                        <br>
                                        <b>Сумма общая:</b> <?php echo e($item->price ? $item->price : '0'); ?> сум
                                    </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php $__currentLoopData = $val->statistics(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <td>
                                            <b>Кол-во:</b> <?php echo e($item->cnt); ?>

                                            <br>
                                            <b>Сумма общая:</b> <?php echo e($item->price ? $item->price : '0'); ?> сум
                                        </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </tbody>
                    </table>
                </div><!-- /.box -->

            </div>


        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.main.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/lebazar/resources/views/admin/statistics/index.blade.php ENDPATH**/ ?>