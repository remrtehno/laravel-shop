<?php $__env->startSection('content'); ?>

<section class="user-cabinet beauty-wrapper">
            <div class="row">
                <div class="small-12 medium-12 columns">
                    <h1 class="title hide-for-small-only hide-for-medium-only hide-for-large-only">
                        <?php echo app('translator')->getFromJson('home.profile_my'); ?>
                    </h1>
                </div>
                <div class="small-12 medium-3 columns">
                    
                      <?php echo $__env->make("profile.lib.left", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    
                </div>
                <div class="small-12 medium-9 columns details">
                    <div class="latest-orders cabinet-block">
                        <h4 class="widget-title">
                            <?php echo app('translator')->getFromJson('home.orders'); ?>
                        </h4>
                        <div class="score_main">
                           
                            <table class="score table">
                                <thead>
                                    <tr>
                                        <th><?php echo app('translator')->getFromJson('home.orders_name'); ?></th>
                                        <th>
                                            <?php echo app('translator')->getFromJson('home.orders_sum'); ?>
                                        </th>
                                        <th>
                                            <?php echo app('translator')->getFromJson('home.orders_status'); ?>
                                        </th>
                                    </tr>
                                    <?php if($orders->count() > 0): ?>
                                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
                                        <tr>
                                            <td><?php echo e($item->tovar_name); ?></td>
                                            <td><?php echo e($item->tovar_price); ?></td>
                                            <td><?php echo e($item->status); ?></td>
                                        </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <tr><td><?php echo app('translator')->getFromJson('home.nothing'); ?></td></tr>
                                    <?php endif; ?>
                                </thead>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </section>



<?php $__env->stopSection(); ?>


<?php $__env->startSection('footerinput'); ?>
    <?php echo $__env->make("lib.footerinput", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("main.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/lebazar/resources/views/orders/index.blade.php ENDPATH**/ ?>