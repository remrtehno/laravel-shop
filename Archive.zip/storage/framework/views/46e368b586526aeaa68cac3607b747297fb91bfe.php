<?php $__env->startSection('content'); ?>
    <section class="shop">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3">
                        <section class="shop-item">
                            <h4 class="sc_title sc_title_regular" >
                                <a href="<?php echo e(route('shop-detail',['slug'=>$item->slug])); ?>">
                                    <?php echo e($item->title); ?>

                                </a>
                            </h4>
                            <a href="<?php echo e(route('shop-detail',['slug'=>$item->slug])); ?>"> <img src="<?php echo e($item->getImage()); ?>" alt=""></a>
                                <div class="wpb_text_column wpb_content_element  custom_1432116266774">
                                <div class="wpb_wrapper">
                                <p><p><?php echo str_limit($item->anonce,350); ?>  </p></p>
                                <a href="<?php echo e(route('shop-detail',['slug'=>$item->slug])); ?>" class="sc_button sc_button_square sc_button_style_button-2 sc_button_bg_link sc_button_size_medium add_link">
                                <span class="button-up">Подробно</span>
                                <i class="fas fa-arrow-alt-circle-right" style="margin-left: 5px;"></i> 
                                </a>
                            </div>
                            </div>
                        </section>
                    </div><!-- /.col-md-3 -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div><!-- /.row -->
        </div><!-- /.container -->
    </section><!-- /.shop -->
<?php echo $__env->make('lib.advantages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>


<?php echo $__env->make("main.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/lebazar/resources/views/shops/index.blade.php ENDPATH**/ ?>