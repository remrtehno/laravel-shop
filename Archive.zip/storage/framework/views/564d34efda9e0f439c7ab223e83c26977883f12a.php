<?php $__env->startSection('content'); ?>

            <section class="user-cabinet beauty-wrapper">
            <div class="row">
                <div class="small-12 medium-12 columns">
                    <h1 class="title hide-for-small-only hide-for-medium-only hide-for-large-only"> Мой профиль </h1>
                </div>
  <div class="small-12 medium-3 columns">
                <?php echo $__env->make("profile.lib.left", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

                <div class="small-12 medium-9 columns details">
                    <div class="latest-orders cabinet-block">
                        <h4 class="widget-title">Просмотренные</h4>
                        <?php if($products->count()): ?>
                <div class="similar-products beauty-wrapper animated fadeInUp normal">



                                    <div class="small-12">
                                        <h4 class="section-title beauty-title">Каталог лучших предложений</h4>
                                        <div>
                                            <section class="products-container products-container-wrap">
                                                <div class="row small-up-2 medium-up-4 large-up-4" style="padding-left: 15px; padding-right: 15px">
                                                     <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       
                                       
                                                    <div class="column no-column-padding">
                                                        <div class="product-item"> 
                                                            <a class="clickable" aria-current="false" href="<?php echo e(route('detail',['slug'=>$val->slug])); ?>">
                                                                <?php if($val->label): ?>
                                                                <div class="label-container"> <span class="label sale alert inline"><?php echo e($val->label); ?> %</span> </div>
                                                                <?php endif; ?>
                                                                <div class="bottom">
                                                                    <div class="product-image">
                                                                        <img src="<?php echo e($val->getImage()); ?>" class="product-img square-180" />
                                                                    </div>
                                                                    <h4 class="product-title"><?php echo e($val->title); ?></h4>
                                                                    <div class="product__price clearfix"> 
                                                                        <strong> <?php echo e($val->price); ?> <span>сум. за</span> <span class="unit-text">1 шт</span> </strong> <span class="small__text hide">( 4 990 сум. за 1 шт )</span>
                                                                </div>
                                                                <div class="add-cart horizontal cart-44732 wide-box not-added"> <button class="button expanded add-to-cart"> <span class="gl-shopping-cart"></span> В корзину </button> </div>
                                                            </a> </div>
                                                    </div>
                                                </div>


                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    
                                                </div>
                                            </section>




                        </div>
                    </div>
                </div>
                <?php else: ?>
                <p style="padding: 30px;">Пусто</p>
                <?php endif; ?>
                    </div>
                   
                </div>
            </div>
        </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("main.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/lebazar/resources/views/profile/index/watchlist.blade.php ENDPATH**/ ?>