<?php $__env->startSection("content"); ?>


    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                Статистика
                <small>it all starts here</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#">Examples</a></li>
                <li class="active">Все заказы</li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">

            <!-- Default box -->
                <div class="box" style="padding: 20px 20px; padding-bottom: 10px; margin: 0; margin-top: 15px;">
                    <?php $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <form action="<?php echo e(route('statisics.show', ['id' => $item->id])); ?>" method="get">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="to" value="" placeholder="до" style="float: right;">
                        <input type="hidden" name="from" value="">

                        <button style="float: right;">Сбросить фильтр</button>


                        </form>


                        <form action="<?php echo e(route('statisics.show', ['id' => $item->id])); ?>" method="get">
                        <?php echo csrf_field(); ?>
                        <h4 align="center" style="float: left;">Выберите дату</h4>
                        <button style="float: right;">Показать</button>

                        <input class="datapicker" data-date-format="mm/dd/yyyy" name="to" value="<?php echo e($to); ?>"
                        placeholder="до" style="float: right;">
                        <input class="datapicker" data-date-format="yyyy-mm-dd " name="from" value="<?php echo e($from); ?>"
                        placeholder="от" style="float: right;">
                        <div style="clear: both;"></div>
                    </form>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>


                <div class="box" style="padding: 20px 20px; padding-bottom: 10px; margin: 0; margin-top: 15px;">

                    <?php $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <h3><?php echo e($item->title); ?></h3>


                    <?php if(count($item->statisticsByDate($from, $to))): ?>
                        <br>


                        <div class="clearfix"></div>


                        <div class="box">


                            <table class="table">
                                <thead>
                                <tr>
                                    <th>Дата</th>
                                    <th>Количество</th>
                                    <th>Цена</th>
                                </tr>
                                </thead>

                                <tbody>
                                <?php $__currentLoopData = $item->statisticsByDate($from, $to); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <b> <?php if($from || $to): ?>
                                                    <?php echo e($from ? 'от' : ''); ?> <?php echo e($from); ?> <?php echo e($to ? 'до' : ''); ?> <?php echo e($to); ?>

                                                <?php else: ?>
                                                    За сегодня
                                                <?php endif; ?>
                                            </b>
                                        </td>
                                        <td>
                                            <?php echo e($val->cnt); ?>

                                        </td>
                                        <td>
                                            <?php echo e($val->price ? $val->price : '0'); ?> сум <br>
                                            <b>Ваш доход:</b> <?php echo e($val->price ? $val->price * $precentage->text : '0'); ?>сум.
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php $__currentLoopData = $item->statistics(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <b> Общее за все время</b>
                                        </td>
                                        <td>
                                            <?php echo e($val->cnt); ?>

                                        </td>
                                        <td>
                                            <?php echo e($val->price ? $val->price : '0'); ?> сум <br>
                                            <b>Ваш доход:</b> <?php echo e($val->price ? $val->price * $precentage->text : '0'); ?>сум.
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div><!-- /.box -->




                    <?php else: ?>
                        <td colspan="5"><h3 align="center">Пусто</h3></td>
                    <?php endif; ?>


                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.main.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/lebazar/resources/views/admin/statistics/detail.blade.php ENDPATH**/ ?>