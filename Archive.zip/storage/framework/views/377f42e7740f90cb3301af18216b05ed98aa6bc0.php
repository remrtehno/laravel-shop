







<?php $__env->startSection('content'); ?>







   <main>
   	<section class="home-page">
            <div class="home-intro">
							<?php $__env->startSection('slider'); ?>
							    <?php echo $__env->make("lib.slider", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
							<?php $__env->stopSection(); ?>



<!-- categories -->
	                <section class="property">
                    <div class="container">
                        <div class="slick-categories">
                            <?php $__currentLoopData = $product_cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item-slide"> 


                                <a href="<?php echo e(route('category',['slug'=>$cat->slug])); ?>">
                                    <img src="<?php echo e($cat->getImage()); ?>" alt="" />

                                    <p><?php echo e($cat->title); ?></p>
                                </a> 
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      
                        </div>
                    </div>
                </section>


                <section class="products-container products-slider IS_BEST_OFFER_ProductCarousel show">
                    <div class="row">
                        <div class="small-12">
                            <h4 class="section-title"> Каталог лучших предложений
                             <a class="button btn-all-link" aria-current="false" href="<?php echo e(route('products', ['slug' => 'hits'])); ?>"> Все
                                    <i class="fa fa-angle-right"></i>
                                </a> </h4>
                            <div>
                                <section class="products-container products-container-wrap">
                                    <div class="row small-up-2 medium-up-4 large-up-6" style="padding-left: 15px; padding-right: 15px">

                                         <?php $__currentLoopData = $productsHits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                               <div class="column no-column-padding">
                                            <div class="product-item"> 
                                                
                                                    <?php if($val->label): ?>
                                                    <div class="label-container"> <span class="label sale alert inline"><?php echo e($val->label); ?> %</span> </div>
                                                    <?php endif; ?>
                                                    
                                                    <div class="bottom">
                                                        <a class="clickable" aria-current="false" href="<?php echo e(route('detail',['slug'=>$val->slug])); ?>">
                                                        <div class="product-image">
                                                            <div class="overlay"><i class="fa fa-eye" aria-hidden="true"></i> Подробнее</div>
                                                            <img src="<?php echo e($val->getImage()); ?>" class="product-img square-180" />
                                                        </div>
                                                        <h4 class="product-title"><?php echo e($val->title); ?></h4>
                                                        <div class="product__price clearfix"> 
                                                            <strong> <?php echo e($val->price); ?> <span>сум. за</span> <span class="unit-text">1 шт</span> </strong> <span class="small__text hide">( 4 990 сум. за 1 шт )</span>
                                                    </div>
                                                </a>

                                                    <div class="add-cart horizontal cart-44732 wide-box not-added">
                                                     <button class="button expanded add-to-cart"> <span class="gl-shopping-cart"><a style="color:white;" aria-current="false" href="<?php echo e(route('add',['slug'=>$val->id])); ?>"></span> В корзину</a> </button> </div>
                                                 </div>
                                        </div>
                                    </div>  <!-- column -->


                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    
                                    </div>
                                </section>
                            </div>
                        </div>
                    </div>
                </section>
                <section class="products-container products-slider IS_BEST_OFFER_ProductCarousel show">
                    <div class="row">
                        <div class="small-12">
                            <h4 class="section-title">
                                Скидочные товары
                                <a class="button btn-all-link" aria-current="false" href="<?php echo e(route('products',['slug' => 'sale'])); ?>">
                                    Все
                                    <i class="fa fa-angle-right"></i>
                                </a>
                            </h4>
                            <div>
                                <section class="products-container products-container-wrap">
                                    <div class="row small-up-2 medium-up-4 large-up-6" style="padding-left: 15px; padding-right: 15px">
                                         <?php $__currentLoopData = $productsSale; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       
                                       
                                        <div class="column no-column-padding">
                                            <div class="product-item"> 
                                                
                                                    <?php if($val->label): ?>
                                                    <div class="label-container"> <span class="label sale alert inline"><?php echo e($val->label); ?> %</span> </div>
                                                    <?php endif; ?>
                                                    
                                                    <div class="bottom">
                                                        <a class="clickable" aria-current="false" href="<?php echo e(route('detail',['slug'=>$val->slug])); ?>">
                                                        <div class="product-image">
                                                            <div class="overlay"><i class="fa fa-eye" aria-hidden="true"></i> Подробнее</div>
                                                            <img src="<?php echo e($val->getImage()); ?>" class="product-img square-180" />
                                                        </div>
                                                        <h4 class="product-title"><?php echo e($val->title); ?></h4>
                                                        <div class="product__price clearfix"> 
                                                            <strong> <?php echo e($val->price); ?> <span>сум. за</span> <span class="unit-text">1 шт</span> </strong> <span class="small__text hide">( 4 990 сум. за 1 шт )</span>
                                                    </div>
                                                </a>

                                                    <div class="add-cart horizontal cart-44732 wide-box not-added">
                                                     <button class="button expanded add-to-cart"> <span class="gl-shopping-cart"><a style="color:white;" aria-current="false" href="<?php echo e(route('add',['slug'=>$val->id])); ?>"></span> В корзину</a> </button> </div>
                                                 </div>
                                        </div>
                                    </div>  <!-- column -->


                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </div>
                                </section>
                            </div>
                        </div>
                    </div>
                </section>
                

            </div>
            <!--home-intro-->
        </section>
    </main>



<?php echo $__env->make('lib.advantages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('footerinput'); ?>
    <?php echo $__env->make("lib.footerinput", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("main.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/lebazar/resources/views/index/index.blade.php ENDPATH**/ ?>