<?php $__env->startSection('content'); ?>

            <section class="user-cabinet beauty-wrapper">
            <div class="row">
                <div class="small-12 medium-12 columns">
                    <h1 class="title hide-for-small-only hide-for-medium-only hide-for-large-only"> Мой профиль </h1>
                </div>

  <div class="small-12 medium-3 columns">
                <?php echo $__env->make("profile.lib.left", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

                <div class="small-12 medium-9 columns details">
                    <form method="post" action="<?php echo e(route('products.update',['id'=>$sl->id])); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
<?php echo e(method_field('PUT')); ?>

                <!-- Default box -->
               
                    <div class="box-body">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Имя</label>
                                <input type="text" class="form-control" id="exampleInputEmail1" placeholder="" value="<?php echo e($sl->title); ?>" name="title">
                            </div>

                            <div class="form-group">
                                <label>Магазин</label>
                                <select class="form-control select2" style="width: 100%;"  name="shop_id">
                                    <?php $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option
                                               <?php if($sl->shop_id == $item->id): ?>
                                                    selected
                                               <?php endif; ?>
                                                value="<?php echo e($item->id); ?>"><?php echo e($item->title); ?></option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

<br>
                            <div class="form-group">
                                <label>Категория</label>
                                <select class="form-control select2" style="width: 100%;"  name="category_id">
                                    <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option
                                                <?php if($item->id == $sl->cat_id): ?> selected="selected"

                                                <?php endif; ?>
                                                value="<?php echo e($item->id); ?>"><?php echo e($item->title); ?></option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <br>

                            <div class="form-group">
                                <label>
                                    Распродажа
                                    <input 
                                        name="is_sale" 
                                        <?php if($sl->is_sale): ?> 
                                            checked
                                        <?php endif; ?>
                                        type="checkbox"
                                        >
                                </label>
                            </div>

                            <div class="form-group">
                                <label>
                                    Лучшее предложение
                                    <input 
                                        name="is_hits" 
                                        <?php if($sl->is_hits): ?> 
                                            checked
                                        <?php endif; ?>
                                        type="checkbox"
                                        >
                                </label>
                            </div>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Цена</label>
                                <input type="text" class="form-control" id="exampleInputEmail1" placeholder="" name="price" value="<?php echo e($sl->price ? $sl->price : $sl->price); ?>" >
                            </div>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Скидка</label>
                                <input type="text" class="form-control" id="exampleInputEmail1" placeholder="" name="label" value="<?php echo e($sl->label); ?>" >
                            </div>


                            <div class="form-group">
                                <img src="<?php echo e($sl->getImage()); ?>" alt="" width="200">
                                <label for="exampleInputFile">Картинка</label>
                                <input type="file" id="exampleInputFile" name="img">

                                <p class="help-block">png,jpeg,jpg размер 400x266</p>
                            </div>


                            <div class="form-group">
                                <label for="exampleInputEmail1">Мета-ключевые слова, через запятую</label>
                                <input type="text" class="form-control" id="exampleInputEmail1" placeholder="" name="meta_key" value="<?php echo e($sl->meta_key); ?>" >
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Мета-описание</label>
                                <input type="text" class="form-control" id="exampleInputEmail1" placeholder="" name="meta_desc" value="<?php echo e($sl->meta_desc); ?>" >
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Описание</label>
                                <textarea name="anonce" id="editor" cols="30" rows="10" class="form-control" ><?php echo e($sl->anonce); ?></textarea>
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Полный текст</label>
                                <textarea  id="" cols="30" rows="10" class="form-control" name="text"><?php echo e($sl->text); ?></textarea>
                            </div>
                        </div>
                    </div>


                    <!-- /.box-body -->
                    <div class="box-footer">
                        <button class="btn btn-success pull-right" type="submit">Отправить</button>
                    </div>
                    <!-- /.box-footer-->
                </div>

            </form>

                    
                </div>
                </div>
            </div>
        </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("main.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/lebazar/resources/views/profile/post/edit.blade.php ENDPATH**/ ?>