<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    //
	 protected $fillable = ['user_id', 'meta','shop_id', 'tovar_price', 'tovar_name', 'status'];


	 public function getMeta($field) {
	 	if($this->meta)
	 	return unserialize($this->meta)[$field];
	 }

	 public function typeBill() {
	 	$money = $this->getMeta('money');
	 	if($money == 'on') {
	 		return 'Наличными';
	 	}

	 }
}
