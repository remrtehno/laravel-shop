<?php $__env->startSection('content'); ?>

            <section class="user-cabinet beauty-wrapper">
            <div class="row">
                <div class="small-12 medium-12 columns">
                    <h1 class="title hide-for-small-only hide-for-medium-only hide-for-large-only"> Мой профиль </h1>
                </div>

  <div class="small-12 medium-3 columns">
                <?php echo $__env->make("profile.lib.left", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

                <div class="small-12 medium-9 columns details">
                    <form method="post" action="<?php echo e(route('seller-shops.update',['id'=>$sl->id])); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
<?php echo e(method_field('PUT')); ?>

                <!-- Default box -->
               
                    <div class="box-body row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Имя</label>
                                <input type="text" class="form-control" id="exampleInputEmail1" placeholder="" value="<?php echo e($sl->title); ?>" name="title">
                            </div>

                               
                        </div>


                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Адрес</label>
                                    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="" value="<?php echo e($sl->address); ?>" name="address">
                                </div>

                               
                            </div>

                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Координаты на карте</label>
                                    <input type="text" value="<?php echo e($sl->map); ?>" class="form-control" placeholder="41.77382, 60.883214" id="exampleInputEmail1" placeholder="" name="map">
                                </div>

                               
                            </div>

                             <div class="form-group col-md-12">
                                <img src="<?php echo e($sl->getImage()); ?>" alt="" width="200">
                                <label for="exampleInputFile">Картинка</label>
                                <input type="file" id="exampleInputFile" name="img">

                                <p class="help-block">png,jpeg,jpg размер 400x266</p>
                            </div>

                             

                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Описание</label>
                                <textarea name="anonce" id="editor" cols="30" rows="10" class="form-control" ><?php echo e($sl->anonce); ?></textarea>
                            </div>
                        </div>

                       
                    </div>


                    <!-- /.box-body -->
                    <div class="box-footer">
                        <button class="btn btn-success pull-right" type="submit">Отправить</button>
                    </div>
                    <!-- /.box-footer-->
                </div>

            </form>

                    
                </div>
                </div>
            </div>
        </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("main.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/lebazar/resources/views/profile/shops/edit.blade.php ENDPATH**/ ?>